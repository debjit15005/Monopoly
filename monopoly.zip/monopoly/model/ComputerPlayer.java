package monopoly.model;


 
/** A subclass of Player for a computer player */
public class ComputerPlayer extends Player
{
   

   public void makeMove()
   {  
   }
   
}
